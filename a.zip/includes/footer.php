<div class="footer-container">
    <footer id="footer" class="footer">

        <h2>Connect with Us </h2>
        <p>GameRank is your go-to destination for ranking, rating, and awarding the best video games of the year.
            Discover
            top-rated games, vote for your favorites, and explore the winners of the annual GameRank Awards. Whether
            you're a casual
            gamer or a hardcore fan, GameRank celebrates the creativity, gameplay, and impact of the gaming world.
        </p>


        <ul>
            <li><button class="btn-W" on onclick="window.location.href='mailto:abdullrazaq.naqsho13@gmail.com'">
                    Mailus📧</button>
            </li>
        </ul>



</div>

</footer>