<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_db2";

$conn = mysqli_connect("localhost", "root", "", "login_db2");

?>